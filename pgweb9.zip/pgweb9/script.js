function validateForm() {
    let kecamatan = document.getElementById("kecamatan").value;
    let jumlahPenduduk = document.getElementById("jumlah_penduduk").value;
    let longitude = document.getElementById("longitude").value;
    let latitude = document.getElementById("latitude").value;
    let luas = document.getElementById("luas").value;
    let text = "";

    if (isNaN(luas) || luas < 0) {
        text = "Data luas harus angka dan tidak boleh bernilai negatif";
    }

    document.getElementById("informasi").innerHTML = text;

    if (text) {
        // Stop the form submission 
        return false;
    }

    // Peta akan muncul di sini jika form valid
    initializeMap(latitude, longitude);
    return true;
}

function initializeMap(lat, lon) {
    var map = L.map('map').setView([lat, lon], 13);
    L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap'
    }).addTo(map);
    L.marker([lat, lon]).addTo(map)
        .bindPopup('Lokasi: ' + lat + ', ' + lon)
        .openPopup();
}
